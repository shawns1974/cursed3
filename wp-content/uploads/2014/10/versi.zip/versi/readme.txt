Versi WordPress Changelog

30th November 2013 - Version 1.4
                 - wp 3.7 ready.
                 - Blog single PrettyPhoto fix.
                 - Portfolio Half loading fix.
                 - Shortcodes will now work inside portfolio description.
                 - Search Page fix.
                 - Google maps controls error fix.
                 - Theme Options updated to latest version.
                 - fileadvanced.php error and other errors fixed.
                 - Metaboxes framework updated.
                 - Font Awesome updated to latest version.
                 - Minor Shortcodes, css and script fixes.
                 - Footer caption disappearing fix.
                 - More social Icons for team updated which includes skype, instagram, email, linkedin.
                 - Thumbnails error on portfolio items for responsive devices fixed.
                + Added button Shortcode.

10th July 2013 - Version 1.3
                 - Portfolio PrettyPhoto fix.
                 - Add content in portfolio sections and contact sections.
                 - Minor CSS Fixes.
                 - Added 404 page.
                 - Google Fonts duplicate fix.
                 - Added ON/Off button for google maps in theme options.

5th July 2013 - Version 1.2
                 + Added Mssing Shortcodes and CSS Fixes.
                 + Added Full Width Slider.
                 + Added Image Alignment CSS code.
                 + Added Callout Text On/off option in Slider Section.
                 + Added Portfolio AJAX On/Off Option.
                 + Added Slider Settings Section in Theme Options.
                 + Added Portfolio Settings Section in Theme Options.
                 + Added Portfolio Single Section as side by side (or) Full Width.
                 - Fixed Background Property Issues.
                 - Added Much Detailed DEscription in Documentation.



28th June 2013 - Version 1.1
                 - Fixed home slider callout caption error.
                 - Fixed metabox background bug.


25th June 2013 - Version 1.0

	- Initial Release
