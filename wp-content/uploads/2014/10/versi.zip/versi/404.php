<?php get_header(); ?> 




    <div id="rnr-post-single" class="section post-single"><!-- SECTION -->

      <div class="container">   
            <div class="row">        
                <div class="span12">                
                  <p class="e-mail aligncenter">404</p>
                  <h1 class="aligncenter">Page Not Found</h1>                  
                </div><!-- END SPAN8 -->
             </div>   
      </div>	
		

    </div><!--END SECTION -->





<?php get_footer(); ?>