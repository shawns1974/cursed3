<div class="post clearfix">

	<div class="post-audio">
		<?php echo get_post_meta($post->ID, 'rnr_blogaudiourl', true); ?>
	</div>
	
	<div class="post-single-content">
		<div class="post-excerpt"><?php the_content(); ?></div>	
				<div class="post-single-meta"><?php get_template_part( 'includes/meta-single' ); ?></div>
		
        
        <div class="post-tags styled-list">
            <ul>
                <?php the_tags( '<ul> <li><i class="icon-tags"></i> ', ',&nbsp; </li><li><i class="icon-tags"></i> ', ' </li> </ul>'); ?>
            </ul>
        </div><!-- End of Tags -->
	</div>

</div>
